/*
import { Navigation } from 'react-native-navigation';

import HomeScreen from './auth/HomeScreen';
import LoginScreen from './auth/LoginScreen'; 

export function registerScreens() {
  Navigation.registerComponent('auth.HomeScreen', () => HomeScreen);
  Navigation.registerComponent('auth.LoginScreen', () => LoginScreen);
} 
*/ 
import { AppRegistry } from 'react-native';
import App from './src/App';
