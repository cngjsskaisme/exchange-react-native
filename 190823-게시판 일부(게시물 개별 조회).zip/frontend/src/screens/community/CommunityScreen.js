import React, { Component } from 'react';
import { StyleSheet, Text, View,  TouchableOpacity } from 'react-native';
import { Table, TableWrapper, Row, Rows, Col, Cell } from 'react-native-table-component'; 
import axios from 'axios'; 

//내가 만든 것들
import Button from '../../components/Button'; 
import {server,deviceStorage} from '../../config/config';
 
export default class CommunityScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tableHead: ['No', 'Title', 'Writer', 'Date', 'Hits'], 
      tableData: [{index: '', value:''}],
      posts: [],  // 게시물들을 담은 cursor 객체
      postCount: 0,  // 게시물의 총 갯수 
      startIndex: 0, // 해당 페이지 가장 상위에 있는 게시물의 index 
      perPage: 4, //한 페이지 당 노출되는 게시물의 수 
      currentPage: 0 //현재 페이지 번호. 0쪽 부터 시작
    } 
 
  } 

componentDidMount(){ // 몽고DB에 저장된 게시글들을 불러옴. 디버깅 편하게 하려고 여기다 함. 작업 후 componentDidMount에 내용 옮기기
    var url = server.serverURL + '/process/community';
     axios.post(url)
    .then((response) => {      
      this.setState({    
          posts: response.data.posts, 
          postCount: response.data.pageCount  
    })     
   
    for(var i=0;i<this.state.postCount; i++){ // 전체 게시물을 tableData에 저장
      var addData = [];
      var getdate = new Date(this.state.posts[i].created_at); 
      var date = getdate.getFullYear() + "-" + (getdate.getMonth()*1+1) + "-" + 
               getdate.getDate()  

      addData.push(i+1,this.state.posts[i].title, this.state.posts[i].writer.nickNm, date,this.state.posts[i].hits)     
         this.setState({
          tableData: this.state.tableData.concat({index: i, value: addData})  
        })
       
    }//for 문 닫기   

    var newlist = this.state.tableData.splice(1,this.state.postCount) //this.state.tableData[0] 은 {index: '', value:''} 이므로 이를 제거하는 과정 
    this.setState({
      tableData: newlist
    }) 
    })//then 닫기 
      .catch(function (error) {
        console.log(error);
      }); 
}//componentDidMount 닫기 

// 하단의 버튼 (<<, <, 숫자 등)을 누를 때 currentPage를 바꾸는 함수. setState를 render 안에 못 써서 여기다가 정의 함.
changecurrentPage(page){ 
  if(page >=  Math.ceil(this.state.postCount/this.state.perPage) || page<0) 
    {
      return;
    }
    this.setState({currentPage: page}) 
  }    

gotoPost(index){ //개별 게시물로 이동 
  
  this.props.navigation.navigate('communitypost',{id: this.state.posts[index]._id}); 
}

  
  render() {     
    var currentPage = this.state.currentPage; //현재 페이지 가리킴
    var startindex = (currentPage)*(this.state.perPage);
    var endindex = startindex+this.state.perPage > this.state.postCount ? this.state.postCount:startindex+this.state.perPage; 
    // 한 페이지의 마지막 인덱스가 전체 게시물 갯수 보다 많은 지 체크. 맞다면, 게시물 갯수를 endindex로 삼음. 
    var pagenum = 5; // 화면 하단에 표시되는 페이지의 갯수  
    var totalpage = Math.ceil(this.state.postCount/this.state.perPage);  

    //총 페이지 갯수

  var showData = this.state.tableData.map((items)=> {
      if( (items.index) >= startindex && (items.index) < endindex ){
          return(  
            <Row data={items.value} flexArr={[3,24,7,9,4]} style={styles.row} textStyle={styles.text} onPress={this.gotoPost.bind(this,items.index)}/>
          );
    }
})



//게시물 하단 버튼 관련 
// 게시물 하단에 표시할 이동 버튼 들. 가장 왼쪽 화살표 들
  var pagebottomlist = [ 
      {
        pagevalue: 0, // 해당 버튼을 누를 때 이동할 페이지의 번호
        text: "<<" // 화면에 표시할 기호
      }, 
      {
        pagevalue: currentPage-1, 
        text: "<"
      }
    ]  

    //각 페이지 번호들
    for(var j=0;j<totalpage;j++){
      pagebottomlist.push({pagevalue: j, text: j+1}) //페이지 번호들 추가
    } 

    // 가장 오른 쪽 화살표 들
    pagebottomlist.push({pagevalue: currentPage+1 , text: ">"}) //다음 페이지로 이동
    pagebottomlist.push({pagevalue: totalpage-1 , text: ">>"}) // 맨 뒷 페이지로 이동


    // 페이지 하단 버튼들 + tag. 게시물이 5쪽 초과이고, 현재 페이지가 7쪽이라면, 5~9쪽(사용자가 볼 때) 까지만  + "<, << , >, >> 만 보이게 하려고 if문 씀
    var showpagebottomlist = pagebottomlist.map((item) => {
        if( Math.floor((parseInt(item.text,10)-1)/pagenum) == Math.floor(this.state.currentPage/pagenum) || !(parseInt(item.text,10))){   
        return (
            <View style={styles.btn_view}><TouchableOpacity style={styles.btn} onPress={this.changecurrentPage.bind(this,item.pagevalue)}>
              <Text style={{fontSize: 15, margin: 10}}>{item.text}</Text>
            </TouchableOpacity></View> 
        ); 
        } //if문 닫기
    }); 
//alert(this.state.tableData[0])
    //화면 렌더링
    return (
      <View style={styles.container}> 
        <Row data={this.state.tableHead} flexArr={[3,24,7,9,4]} style={styles.head} textStyle={styles.text}/>  
        {showData}
        <View style={{flexDirection: 'row'}}> 
        {showpagebottomlist}
        </View>
      </View>
    )
  }
}
 
const styles = StyleSheet.create({
  container: { flex: 1,  padding: 16, paddingTop: 200, backgroundColor: '#fff'}, //최상단 View의 스타일 
  head: { height: 40,  backgroundColor: '#f1f8ff'}, //테이블 헤드 부분 스타일 (제목 목록)
  row: {  height: 50, borderBottomWidth: 1}, //테이블 내용 부분 스타일 (게시물 들 목록)
  text: { textAlign: 'center'}, //Row 속 텍스트륻릐 스타일 
  btn: {width: 40,backgroundColor: '#cceeff',borderRadius: 5,  marginTop: 30, marginBottom: 10, alignItems: 'center' },  //페이지 하단 버튼의 스타일
  btn_view: {width: 40}, //페이지 하단 버튼을 덮는 View의  스타일

});