import React, { Component } from 'react';
import { StyleSheet, Text, View,  TouchableOpacity } from 'react-native';
import { Table, TableWrapper, Row, Rows, Col, Cell } from 'react-native-table-component'; 
import axios from 'axios'; 
import { createStackNavigator, createAppContainer } from 'react-navigation';
//내가 만든 것들
import Button from '../../components/Button'; 
import {server,deviceStorage} from '../../config/config';
 
export default class CommunityPostScreen extends Component {
  constructor(props) {
    super(props);  
    this.state = {
      post: {}, 
      writer: ''
    }  
  } 
 componentDidMount(){ 
  var url = server.serverURL + '/process/showpost';
      axios.post(url,{
      id: this.props.navigation.getParam('id'),
    })
    .then((response) => {      
      this.setState({    
          post: response.data.posts,        
          writer: response.data.posts.writer.nickNm //this.state.post.writer.nickNm 직접 접속이 안 ㅚㅁ
      })  
    
    })
    .catch(function (error) {
        console.log(error); 
        alert("에러 발생: "+error+"혹은 존재하지 않는 게시물") 
    }); 

 }//componentDidMount()닫기

 render() {       
    var title = this.state.post.title 
    var content = this.state.post.contents 
    var writer = this.state.writer  
    
    //화면 렌더링
    return (
      <View style={styles.container}>  
      <Text>Title: {title}</Text>       
      <Text>Content: {content}</Text> 
      <Text>Writer: {writer}</Text>
      
      
      </View>
    )
  }
}
 
const styles = StyleSheet.create({
  container: { flex: 1,  padding: 16, paddingTop: 200, backgroundColor: '#fff'},
 /* 
  head: {  height: 40,  backgroundColor: '#f1f8ff'  },
  wrapper: { flexDirection: 'row'},
  title: { flex: 1, backgroundColor: '#f6f8fa' },
  row: {  height: 28  },
  text: { textAlign: 'center'}, 
  btn: {width: 40,backgroundColor: '#cceeff', alignItems: 'center',borderRadius: 5,  marginTop: 30, marginBottom: 10, },  
  btn_view: {width: 40, marginLeft: 10},
*/
});