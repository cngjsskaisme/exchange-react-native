import * as React from 'react';
import { Text, View, StyleSheet, TouchableOpacity, TextInput, ActivityIndicator} from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';
import {
  createSwitchNavigator,
  createAppContainer
} from 'react-navigation'; 

//내가 만든 것들  
import Button from '../../components/Button'; 
import {server,deviceStorage} from '../../config/config';

export default class LoginScreen extends React.Component {
constructor(){
    super();
}

login(){ // 서버의 data path에 id 와 비밀번호 전달
    var url = server.serverURL + '/login';
    axios.post(url, {
      loginId: this.state.loginId,
      password: this.state.password
    })
    .then((response) => {       
        deviceStorage.saveKey("id_token", response.data.accesstoken); //jwt 가져옴     
        var msg = response.data.msg; // 서버로부터 메시지 받음.
        this.props.navigation.navigate('auth',{fromwhere: "login", info: msg}); 
        //fromwhere: 로그인 혹은 가입 실패 시 보여주는 화면을 다르게 하기 위해 추가. info: 실패 원인을 alert로 띄움 
        alert(msg);
      })
      .catch(function (error) {
        console.log(error);
      }); 
      this.setState({loginId: ''});
      this.setState({password: ''});  
  } 
  
  render() { 
    return( 
      <View style={{ flex: 0.5, flexDirection: 'column', alignItems: 'center', paddingTop: 175}}>
      <Text style={{fontSize:20,color:'black',fontWeight:'bold'}}>Login{"\n\n"}
      </Text>
      <TextInput
          value={this.state.loginId}
          onChangeText={(loginId) => this.setState({loginId})}
          style={{ width: 200, height: 44, padding: 8, borderWidth: 1, borderColor: '#ccc'}} 
          placeholder="Enter your ID"
        />    
        
      <TextInput
          value={this.state.password}
          onChangeText={(password) => this.setState({password})}
          secureTextEntry={true} //입력 값 안 보이게
          style={{ width: 200, height: 44, padding: 8, borderWidth: 1, borderColor: '#ccc'}} 
          placeholder="Enter your password"
        />     
      <Button onPress={this.login.bind(this)} title="login"/>
      <Text style={{color: 'blue',textDecorationLine: 'underline'}}
      onPress={() => this.props.navigation.navigate('signup')}>Signup</Text>  
    </View> 
    // 버튼을 나란히 두개 배치하는 방법을 몰라서 대충 a 태그처럼 함 
    );
  }
} 