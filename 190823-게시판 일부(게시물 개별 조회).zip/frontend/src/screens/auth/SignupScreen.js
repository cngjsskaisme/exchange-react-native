import * as React from 'react';
import { Text, View, StyleSheet, TouchableOpacity, TextInput, ActivityIndicator, AsyncStorage} from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';
 
//내가 만든 것들  
import Button from '../../components/Button'; 
import {server, deviceStorage} from '../../config/config'; 
import LoginScreen from './LoginScreen';
import HomeScreen from './HomeScreen'; 
import AuthScreen from './AuthScreen';


export default class SignupScreen extends React.Component {
constructor(){
    super();
    this.state = {
     result:[], 
     accesstoken: '',
     permittednickNm: false, 
     loginId: '',
     password: '', 
     nickNm: '',  
    };
  }
signup(){ // 서버의 data path에 id 와 비밀번호 전달
   
   if(this.state.permittednickNm){ //닉네임 체크를 먼저 하고 난 후에 가입을 하기 위해 이렇게 설정함
      var url = server.serverURL + '/signup';
      axios.post(url, {
        loginId: this.state.loginId,
        password: this.state.password, 
        nickNm: this.state.nickNm
      })
      .then((response) => {       
        deviceStorage.saveKey("id_token", response.data.accesstoken); //jwt 가져옴     
        var msg = response.data.msg; // 서버로부터 메시지 받음.
        this.props.navigation.navigate('auth',{fromwhere: "signup", info: msg});  
        //fromwhere: 로그인 혹은 가입 실패 시 보여주는 화면을 다르게 하기 위해 추가. info: 실패 원인을 alert로 띄움
        alert(msg);
      })
      .catch(function (error) {
        console.log(error);
      }); 
      this.setState({loginId: ''});
      this.setState({password: ''});  
  } 
  else{
    alert("check your nickname first");
  } 
}
checknickNm(){  //가입 전 입력한 닉네임이 유효한 지 체크한다.
  var url = server.serverURL + '/process/checknickNm';
    axios.post(url, { 
      nickNm: this.state.nickNm
    })
    .then((response) => {
      this.setState({ 
        permittednickNm: response.data.permittednickNm
      })    
      if(this.state.nickNm == ''){
        alert("Do not leave nickname as blank. Please fill your nickname and push this button again")
      }
      else if(!this.state.permittednickNm){
        alert("cannot use the nickname. Please input another nickname and check once again")
      } 
        else{
            alert("You can use your nickname") 
        }
    })
    .catch(function (error) {
      console.log(error);
    }); 
} 

render() {  
 
    return(  
      <View style={{ flex: 0.5, flexDirection: 'column', alignItems: 'center', paddingTop: 175}}>
      <Text style={{fontSize:20,color:'black',fontWeight:'bold'}}>Signup{"\n\n"}
      </Text>
      <TextInput
          value={this.state.loginId}
          onChangeText={(loginId) => this.setState({loginId})}
          style={{ width: 200, height: 44, padding: 8, borderWidth: 1, borderColor: '#ccc'}} 
          placeholder="Enter your ID"
        />    
      <TextInput
          value={this.state.password}
          onChangeText={(password) => this.setState({password})}
          secureTextEntry={true} //입력 값 안 보이게
          style={{ width: 200, height: 44, padding: 8, borderWidth: 1, borderColor: '#ccc'}} 
          placeholder="Enter your password"
        /> 
      <TextInput
          value={this.state.nickNm}
          onChangeText={(nickNm) => {this.setState({nickNm}); this.setState({permittednickNm: false});}}
          style={{ width: 200, height: 44, padding: 8, borderWidth: 1, borderColor: '#ccc'}} 
          placeholder="Enter your nickname"
        />  
      <Button onPress={this.signup.bind(this)} title="signup"/> 
      <Button onPress={this.checknickNm.bind(this)} title="check nickname"/>     
      
    </View> 
    // 버튼을 나란히 두개 배치하는 방법을 몰라서 대충 a 태그처럼 함 
    );
  }
} 