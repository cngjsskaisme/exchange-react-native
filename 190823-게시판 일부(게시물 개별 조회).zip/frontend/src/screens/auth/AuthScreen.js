import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios'; 
import { createStackNavigator, createAppContainer } from 'react-navigation';
 
//내가 만든 것들
import Button from '../../components/Button'; 
import {deviceStorage,auth} from '../../config/config'; 

export default class AuthScreen extends React.Component { 
constructor(props){
    super(props);
}  
async componentWillMount() {
    const { navigation } = this.props; 
    const fromwhere = navigation.getParam('fromwhere', 'login');    
    const msg = navigation.getParam('info');  
    
    if (await auth.checkauth()) {
      navigation.navigate("home"); 
    } else {
      navigation.navigate(fromwhere); 
    }      
  }

render(){   
 return( 
      <ActivityIndicator />
 )
}  
}