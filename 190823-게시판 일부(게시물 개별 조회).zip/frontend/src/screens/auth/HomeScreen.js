import * as React from 'react';
import { Text, View, StyleSheet, TouchableOpacity, AsyncStorage} from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';
import { createStackNavigator, createAppContainer } from 'react-navigation';

//내가 만든 것들  
import Button from '../../components/Button';
import {server, deviceStorage, auth} from '../../config/config'; 

export default class HomeScreen extends React.Component {
constructor(props){
    super(props);
}

async logout(){ 
  this.props.navigation.navigate(await auth.logout())
}

goto(where){ 
  this.props.navigation.navigate(where)
} 

render() {   
    return(     
      <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center',alignSelf: 'center'}}>
       
        <Button title="community" onPress = {this.goto.bind(this,'community')}  />
        <Text>{'\u00A0'}</Text> 
        <Button title="rateclass"/> 
        <Text>{'\u00A0'}</Text> 
        <Button title="timetable"/> 
        <Text>{'\u00A0'}</Text>
        <Button title="logout" onPress = {this.logout.bind(this)} />    
    </View>   
    // <Text>{'\u00A0'}</Text>: 버튼 사이에 띄어쓰기 위함.
    );
  }
} 
