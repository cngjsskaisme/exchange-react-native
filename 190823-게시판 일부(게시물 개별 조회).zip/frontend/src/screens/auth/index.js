import { Navigation } from 'react-native-navigation';

import HomeScreen from './HomeScreen';
import LoginScreen from './LoginScreen';  
import SignupScreen from './SignupScreen';
import AuthScreen from './AuthScreen';

export function registerScreens() {
  Navigation.registerComponent('auth.HomeScreen', () => HomeScreen);
  Navigation.registerComponent('auth.LoginScreen', () => LoginScreen);
  Navigation.registerComponent('auth.SignupScreen', () => SignupScreen);
  Navigation.registerComponent('auth.AuthScreen', () => AuthScreen);
}