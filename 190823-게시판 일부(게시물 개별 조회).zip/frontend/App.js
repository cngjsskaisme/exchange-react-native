import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';
import {
  createSwitchNavigator,
  createStackNavigator,
  createAppContainer,
} from 'react-navigation';

//내가 만든 것들
import Button from './src/components/Button';

//인증(auth) 관련 
import LoginScreen from './src/screens/auth/LoginScreen';
import HomeScreen from './src/screens/auth/HomeScreen';
import SignupScreen from './src/screens/auth/SignupScreen'; 
import AuthScreen from './src/screens/auth/AuthScreen'; 
 
//게시판(board) 관련
import CommunityScreen from './src/screens/community/CommunityScreen';
import CommunityPostScreen from './src/screens/community/CommunityPostScreen';

//config 관련
import {deviceStorage} from './src/config/config'; 


export default createAppContainer(createSwitchNavigator( 
  { 
    //인증(auth) 관련 
    login: LoginScreen, 
    home: HomeScreen,  
    signup: SignupScreen,
    auth: AuthScreen, 

    //게시판(board) 관련 
    community: CommunityScreen, 
    communitypost: CommunityPostScreen,

  }, 
  {
    initialRouteName: 'community',
  }
)) 


